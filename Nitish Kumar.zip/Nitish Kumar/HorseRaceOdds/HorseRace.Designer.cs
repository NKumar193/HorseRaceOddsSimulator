﻿namespace HorseRaceOdds
{
    partial class HorseRace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvHorseRunnerDetails = new System.Windows.Forms.DataGridView();
            this.lblHorseName = new System.Windows.Forms.Label();
            this.lblOddPrice = new System.Windows.Forms.Label();
            this.txtHorseName = new System.Windows.Forms.TextBox();
            this.txtOddPrice = new System.Windows.Forms.TextBox();
            this.btnAddHorse = new System.Windows.Forms.Button();
            this.btnRunRace = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHorseRunnerDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvHorseRunnerDetails
            // 
            this.dgvHorseRunnerDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHorseRunnerDetails.Location = new System.Drawing.Point(21, 22);
            this.dgvHorseRunnerDetails.Name = "dgvHorseRunnerDetails";
            this.dgvHorseRunnerDetails.Size = new System.Drawing.Size(240, 150);
            this.dgvHorseRunnerDetails.TabIndex = 0;
            // 
            // lblHorseName
            // 
            this.lblHorseName.AutoSize = true;
            this.lblHorseName.Location = new System.Drawing.Point(297, 34);
            this.lblHorseName.Name = "lblHorseName";
            this.lblHorseName.Size = new System.Drawing.Size(63, 13);
            this.lblHorseName.TabIndex = 1;
            this.lblHorseName.Text = "HorseName";
            // 
            // lblOddPrice
            // 
            this.lblOddPrice.AutoSize = true;
            this.lblOddPrice.Location = new System.Drawing.Point(297, 101);
            this.lblOddPrice.Name = "lblOddPrice";
            this.lblOddPrice.Size = new System.Drawing.Size(51, 13);
            this.lblOddPrice.TabIndex = 2;
            this.lblOddPrice.Text = "OddPrice";
            // 
            // txtHorseName
            // 
            this.txtHorseName.Location = new System.Drawing.Point(366, 31);
            this.txtHorseName.Name = "txtHorseName";
            this.txtHorseName.Size = new System.Drawing.Size(100, 20);
            this.txtHorseName.TabIndex = 3;
            // 
            // txtOddPrice
            // 
            this.txtOddPrice.Location = new System.Drawing.Point(366, 98);
            this.txtOddPrice.Name = "txtOddPrice";
            this.txtOddPrice.Size = new System.Drawing.Size(100, 20);
            this.txtOddPrice.TabIndex = 4;
            // 
            // btnAddHorse
            // 
            this.btnAddHorse.Location = new System.Drawing.Point(366, 166);
            this.btnAddHorse.Name = "btnAddHorse";
            this.btnAddHorse.Size = new System.Drawing.Size(100, 23);
            this.btnAddHorse.TabIndex = 5;
            this.btnAddHorse.Text = "AddHorses";
            this.btnAddHorse.UseVisualStyleBackColor = true;
            this.btnAddHorse.Click += new System.EventHandler(this.btnAddHorse_Click);
            // 
            // btnRunRace
            // 
            this.btnRunRace.Location = new System.Drawing.Point(21, 218);
            this.btnRunRace.Name = "btnRunRace";
            this.btnRunRace.Size = new System.Drawing.Size(114, 32);
            this.btnRunRace.TabIndex = 6;
            this.btnRunRace.Text = "Run Race";
            this.btnRunRace.UseVisualStyleBackColor = true;
            this.btnRunRace.Click += new System.EventHandler(this.btnRunRace_Click);
            // 
            // HorseRace
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 351);
            this.Controls.Add(this.btnRunRace);
            this.Controls.Add(this.btnAddHorse);
            this.Controls.Add(this.txtOddPrice);
            this.Controls.Add(this.txtHorseName);
            this.Controls.Add(this.lblOddPrice);
            this.Controls.Add(this.lblHorseName);
            this.Controls.Add(this.dgvHorseRunnerDetails);
            this.Name = "HorseRace";
            this.Text = "HorseRaceOddSimulator";
            ((System.ComponentModel.ISupportInitialize)(this.dgvHorseRunnerDetails)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvHorseRunnerDetails;
        private System.Windows.Forms.Label lblHorseName;
        private System.Windows.Forms.Label lblOddPrice;
        private System.Windows.Forms.TextBox txtHorseName;
        private System.Windows.Forms.TextBox txtOddPrice;
        private System.Windows.Forms.Button btnAddHorse;
        private System.Windows.Forms.Button btnRunRace;
    }
}