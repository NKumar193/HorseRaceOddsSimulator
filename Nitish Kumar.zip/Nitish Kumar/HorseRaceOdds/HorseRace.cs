﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace HorseRaceOdds
{
    public partial class HorseRace : Form
    {
        public HorseRace()
        {
            InitializeComponent();
            dgvHorseRunnerDetails.ColumnCount = 2;
            dgvHorseRunnerDetails.Columns[0].Name = "Horse Name";
            dgvHorseRunnerDetails.Columns[1].Name = "Odd Price";
            btnRunRace.Enabled = false;
        }


        private void btnAddHorse_Click(object sender, EventArgs e)
        {
            AddRunner(txtHorseName.Text, txtOddPrice.Text);
            txtHorseName.Text = null;
            txtOddPrice.Text = null;
        }
        private void AddRunner(string name, string price)
        {

            if (Regex.IsMatch(name, @"^[a-zA-Z]+$"))
            {
                if(name.Length > 0 && name.Length <= 18) 
                {
                    if (price.Contains("/"))
                    {
                        string [] b=price.Split('/');
                        if (Convert.ToDecimal(b[0])>=1 && Convert.ToDecimal(b[1]) >= 1)
                        {
                            string[] row = { name, price };
                            dgvHorseRunnerDetails.Rows.Add(row);
                        }
                        else
                        {
                            MessageBox.Show("Odd price should be in x/y format where x and y are integers greater than 1");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Odd price should be in x/y format where x and y are integers greater than 1");
                    }
                    
                }
                else
                {
                    MessageBox.Show("The Name should be of maximum 18 characters long");
                }
                
            }
            else
            {
                MessageBox.Show("The Name should contain only characters");
            }
            if ((GetRunnerDetails().Count >= 4) == true && (GetRunnerDetails().Count < 16) == true)
            {
                btnRunRace.Enabled = true;
            }
            else
            {
                MessageBox.Show("No of runners should be lie between 4 and 16");
            }


        }

        private void btnRunRace_Click(object sender, EventArgs e)
        {
            if (GetRunnerDetails()==null)
            {
                btnRunRace.Enabled = false;
            }
            else
            {
                btnRunRace.Enabled = true;
                CalculateWinningChance();
            }
              
        }
        private decimal CalculateRaceMargin()
        {
            Dictionary<string, decimal> runner = GetRunnerDetails();
            decimal raceMargin = 0;
            foreach(var r in runner)
            {
                raceMargin = raceMargin + (100 / r.Value);
            }
            return raceMargin;
        }

        private void CalculateWinningChance()
        {
            Dictionary<string, decimal> runner = GetRunnerDetails();
            decimal overallRaceMargin = CalculateRaceMargin();
            if((overallRaceMargin>110)==true && (overallRaceMargin < 140) == true)
            {
                Dictionary<string, decimal> dict = new Dictionary<string, decimal>();
                foreach (var r in runner)
                {
                    decimal raceMarginForEachRunner = (100 / r.Value);
                    decimal val= (raceMarginForEachRunner / overallRaceMargin) * 100;
                    decimal value= Math.Round(val,2);
                    dict.Add(r.Key, value);
                }
                string max = dict.Aggregate((l, r) => l.Value > r.Value ? l : r).Key;
                MessageBox.Show("Winner of this race is " + max);
            }
            else
            {
                MessageBox.Show("Race Margin should be lie between 110% and 140%");
            }
            
        }

        private Dictionary<string,decimal> GetRunnerDetails()
        {
            Dictionary<string, decimal> runners = new Dictionary<string, decimal>();
            int count = dgvHorseRunnerDetails.RowCount;
            for (int i = 0; i < count - 1; i++)
            {
                string key = dgvHorseRunnerDetails.Rows[i].Cells[0].Value.ToString();
                string str = dgvHorseRunnerDetails.Rows[i].Cells[1].Value.ToString();
                string[] array = str.Split('/');
                decimal value = (Convert.ToDecimal(array[0])+ Convert.ToDecimal(array[1]))/(Convert.ToDecimal(array[1]));
                runners.Add(key, Math.Round(value,2));
            }
            return runners;
        }
    }
}
